import React from "react";


 function Note(){
   return (
     
    <div className="note">
    <h1> JavaScript and React.js </h1>
    <p>This is the best bootcamp for those who  are looking to learn Javascript  and React JS  from the scratch. </p>
    
    </div>
  
     
     


     
   );
  
  }
  export default Note;